
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.acesbrain.sillymod.SillymodMod;

public class SillymodModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SillymodMod.MODID);
	public static final RegistryObject<SoundEvent> YIPPEE = REGISTRY.register("yippee", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sillymod", "yippee")));
}
