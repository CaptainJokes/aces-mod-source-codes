
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.acesbrain.sillymod.item.SillyIngotItem;
import net.acesbrain.sillymod.item.SillyDustItem;
import net.acesbrain.sillymod.item.RawSillyItem;
import net.acesbrain.sillymod.item.LiquidSillyItem;
import net.acesbrain.sillymod.SillymodMod;

public class SillymodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SillymodMod.MODID);
	public static final RegistryObject<Item> LIQUID_SILLY_BUCKET = REGISTRY.register("liquid_silly_bucket", () -> new LiquidSillyItem());
	public static final RegistryObject<Item> SILLY_BLOCK = block(SillymodModBlocks.SILLY_BLOCK);
	public static final RegistryObject<Item> SILLY_ORE = block(SillymodModBlocks.SILLY_ORE);
	public static final RegistryObject<Item> DEEPSLATE_SILLY_ORE = block(SillymodModBlocks.DEEPSLATE_SILLY_ORE);
	public static final RegistryObject<Item> RAW_SILLY = REGISTRY.register("raw_silly", () -> new RawSillyItem());
	public static final RegistryObject<Item> SILLY_INGOT = REGISTRY.register("silly_ingot", () -> new SillyIngotItem());
	public static final RegistryObject<Item> SILLY_DUST = REGISTRY.register("silly_dust", () -> new SillyDustItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
