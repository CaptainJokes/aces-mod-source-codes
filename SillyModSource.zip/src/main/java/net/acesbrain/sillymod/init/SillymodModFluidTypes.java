
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.acesbrain.sillymod.fluid.types.LiquidSillyFluidType;
import net.acesbrain.sillymod.SillymodMod;

public class SillymodModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, SillymodMod.MODID);
	public static final RegistryObject<FluidType> LIQUID_SILLY_TYPE = REGISTRY.register("liquid_silly", () -> new LiquidSillyFluidType());
}
