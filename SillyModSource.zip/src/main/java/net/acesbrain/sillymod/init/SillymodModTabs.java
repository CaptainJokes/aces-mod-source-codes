
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.acesbrain.sillymod.SillymodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SillymodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SillymodMod.MODID);
	public static final RegistryObject<CreativeModeTab> SILLY_STUFF = REGISTRY.register("silly_stuff",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.sillymod.silly_stuff")).icon(() -> new ItemStack(SillymodModItems.SILLY_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(SillymodModItems.LIQUID_SILLY_BUCKET.get());
				tabData.accept(SillymodModBlocks.SILLY_BLOCK.get().asItem());
				tabData.accept(SillymodModBlocks.SILLY_ORE.get().asItem());
				tabData.accept(SillymodModBlocks.DEEPSLATE_SILLY_ORE.get().asItem());
				tabData.accept(SillymodModItems.RAW_SILLY.get());
				tabData.accept(SillymodModItems.SILLY_INGOT.get());
				tabData.accept(SillymodModItems.SILLY_DUST.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SillymodModItems.LIQUID_SILLY_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(SillymodModBlocks.SILLY_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SillymodModBlocks.SILLY_ORE.get().asItem());
			tabData.accept(SillymodModBlocks.DEEPSLATE_SILLY_ORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SillymodModItems.RAW_SILLY.get());
			tabData.accept(SillymodModItems.SILLY_INGOT.get());
			tabData.accept(SillymodModItems.SILLY_DUST.get());
		}
	}
}
