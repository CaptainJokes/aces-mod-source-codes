
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.acesbrain.sillymod.SillymodMod;

public class SillymodModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SillymodMod.MODID);
	public static final RegistryObject<SimpleParticleType> SILLY_PART = REGISTRY.register("silly_part", () -> new SimpleParticleType(false));
}
