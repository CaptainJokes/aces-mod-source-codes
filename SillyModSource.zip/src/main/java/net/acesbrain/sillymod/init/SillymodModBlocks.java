
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.acesbrain.sillymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.acesbrain.sillymod.block.SillyOreBlock;
import net.acesbrain.sillymod.block.SillyBlockBlock;
import net.acesbrain.sillymod.block.LiquidSillyBlock;
import net.acesbrain.sillymod.block.DeepslateSillyOreBlock;
import net.acesbrain.sillymod.SillymodMod;

public class SillymodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SillymodMod.MODID);
	public static final RegistryObject<Block> LIQUID_SILLY = REGISTRY.register("liquid_silly", () -> new LiquidSillyBlock());
	public static final RegistryObject<Block> SILLY_BLOCK = REGISTRY.register("silly_block", () -> new SillyBlockBlock());
	public static final RegistryObject<Block> SILLY_ORE = REGISTRY.register("silly_ore", () -> new SillyOreBlock());
	public static final RegistryObject<Block> DEEPSLATE_SILLY_ORE = REGISTRY.register("deepslate_silly_ore", () -> new DeepslateSillyOreBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
