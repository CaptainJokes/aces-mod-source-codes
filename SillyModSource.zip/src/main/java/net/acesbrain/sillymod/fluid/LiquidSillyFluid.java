
package net.acesbrain.sillymod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleOptions;

import net.acesbrain.sillymod.init.SillymodModParticleTypes;
import net.acesbrain.sillymod.init.SillymodModItems;
import net.acesbrain.sillymod.init.SillymodModFluids;
import net.acesbrain.sillymod.init.SillymodModFluidTypes;
import net.acesbrain.sillymod.init.SillymodModBlocks;

public abstract class LiquidSillyFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> SillymodModFluidTypes.LIQUID_SILLY_TYPE.get(), () -> SillymodModFluids.LIQUID_SILLY.get(), () -> SillymodModFluids.FLOWING_LIQUID_SILLY.get())
			.explosionResistance(100f).tickRate(4).slopeFindDistance(5).bucket(() -> SillymodModItems.LIQUID_SILLY_BUCKET.get()).block(() -> (LiquidBlock) SillymodModBlocks.LIQUID_SILLY.get());

	private LiquidSillyFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return (SimpleParticleType) (SillymodModParticleTypes.SILLY_PART.get());
	}

	public static class Source extends LiquidSillyFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends LiquidSillyFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
