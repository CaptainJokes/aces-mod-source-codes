
package net.acesbrain.sillymod.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.acesbrain.sillymod.init.SillymodModFluids;

public class LiquidSillyBlock extends LiquidBlock {
	public LiquidSillyBlock() {
		super(() -> SillymodModFluids.LIQUID_SILLY.get(), BlockBehaviour.Properties.of().mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}
