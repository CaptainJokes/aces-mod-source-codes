
package net.acesbrain.sillymod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.acesbrain.sillymod.init.SillymodModFluids;

public class LiquidSillyItem extends BucketItem {
	public LiquidSillyItem() {
		super(SillymodModFluids.LIQUID_SILLY, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.UNCOMMON));
	}
}
