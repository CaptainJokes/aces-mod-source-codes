
package net.acesbrain.sillymod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SillyDustItem extends Item {
	public SillyDustItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
