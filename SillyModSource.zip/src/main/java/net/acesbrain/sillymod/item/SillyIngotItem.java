
package net.acesbrain.sillymod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SillyIngotItem extends Item {
	public SillyIngotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
